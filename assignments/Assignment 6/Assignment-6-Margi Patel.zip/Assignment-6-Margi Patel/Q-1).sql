CREATE OR REPLACE PROCEDURE insert_glaccount
(
    account_number     NUMBER,
    account_description    VARCHAR2
   
)
AS

BEGIN
    INSERT INTO general_ledger_accounts
    VALUES(account_number, account_description);
    
    COMMIT;
EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
END;
/

CALL insert_glaccount(1,'Tax');