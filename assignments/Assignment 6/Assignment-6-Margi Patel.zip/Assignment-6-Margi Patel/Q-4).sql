--Margi Patel
--Assignment-6
--4)


CREATE OR REPLACE FUNCTION test_glaccounts_description
(
  account_description_param VARCHAR2
)
RETURN NUMBER
AS
  account_number_param NUMBER;
BEGIN 
  SELECT account_number
  INTO account_number_param
  FROM general_ledger_accounts
  WHERE account_description = account_description_param;

    IF SQL%ROWCOUNT = 1 THEN
    
    RETURN 1;
  END IF;   


  RETURN account_number_param;
  
EXCEPTION

    WHEN NO_DATA_FOUND THEN 
    account_number_param := 0;
    RETURN 0;
   -- WHEN OTHERS  THEN
   
   -- RETURN 1;
    
        ROLLBACK;
  
END;
/

SELECT test_glaccounts_description('Cash') FROM dual; --input value which is in account_decription ,will be return 0
SELECT test_glaccounts_description('dfgz') FROM dual; --input value which is not in account_decription ,will be return 0


SET SERVEROUTPUT ON
BEGIN
--it will call function & print  'Account description is already in use'
  IF test_glaccounts_description('Cash') = 1 THEN
        DBMS_OUTPUT.PUT_LINE('Account description is already in use');
  ELSE
        DBMS_OUTPUT.PUT_LINE('Account description is available');  
  END IF;  

--it will call function & print  'Account description is available'  
  IF test_glaccounts_description('Bed') = 1 THEN
    DBMS_OUTPUT.PUT_LINE('Account description is already in use');
  ELSE
    DBMS_OUTPUT.PUT_LINE('Account description is available');  
  END IF;  
END;