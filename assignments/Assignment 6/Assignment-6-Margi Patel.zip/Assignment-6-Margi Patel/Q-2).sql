--Margi Patel
--Assignment-6
--2)


DECLARE 

        account_number NUMBER;
        account_description VARCHAR2;

CREATE OR REPLACE PROCEDURE insert_glaccount
(
    account_number_param     NUMBER,
    account_description_param    VARCHAR2
   
)



AS




BEGIN
        IF   account_number = account_number_param 
        THEN RAISE VALUE_ERROR;
        END IF;

    
    
    COMMIT;

END;
/


SET SERVEROUTPUT ON;

BEGIN 
    insert_glaccount(1,'Tax');
EXCEPTION
    WHEN DUP_VAL_ON_INDEX THEN 
    DBMS_OUTPUT.PUT_LINE('A DUP_VAL_ON_INDEX error occurred.');
    WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE('An unknown exception occurred.');
        ROLLBACK;
END;
/




