-- Assignment 6- Q3
-- Ekta Patel(N01137684)


CREATE OR REPLACE FUNCTION test_glaccounts_description
(
  account_description_param general_ledger_accounts.account_description%TYPE
)
RETURN NUMBER
AS
  acc_number_var general_ledger_accounts.account_number%TYPE;
BEGIN 
  SELECT account_number
  INTO acc_number_var
  FROM general_ledger_accounts
  WHERE account_description = account_description_param;
  -- Reference from stack overflow for ROWCOUNT
  IF SQL%ROWCOUNT = 1 THEN
    RETURN 1;
  END IF;   
EXCEPTION  
  WHEN NO_DATA_FOUND THEN
    RETURN 0;
END;
/
