-- Assignment 6- Q2
-- Ekta Patel(N01137684)

SET SERVEROUTPUT ON;

BEGIN 
    insert_glaccount(600, 'Donation');
    
    COMMIT;
EXCEPTION
    WHEN DUP_VAL_ON_INDEX THEN
        DBMS_OUTPUT.PUT_LINE('A DUP_VAL_ON_INDEX error occured.');
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('An unknown exception occurred.');
END;
/


