-- Assignment 6- Q1
-- Ekta Patel(N01137684)

CREATE OR REPLACE PROCEDURE insert_glaccount
(
    account_number_param general_ledger_accounts.account_number%TYPE,
    account_description_param general_ledger_accounts.account_description%TYPE
)
AS
BEGIN
    INSERT INTO general_ledger_accounts
    VALUES (account_number_param, account_description_param);
    
    COMMIT;
EXCEPTION
WHEN DUP_VAL_ON_INDEX THEN
        DBMS_OUTPUT.PUT_LINE('A DUP_VAL_ON_INDEX error occured.');
    WHEN OTHERS THEN
        ROLLBACK;
END;
/

CALL insert_glaccount(600, 'Donation');


SELECT * FROM general_ledger_accounts WHERE account_number=600;