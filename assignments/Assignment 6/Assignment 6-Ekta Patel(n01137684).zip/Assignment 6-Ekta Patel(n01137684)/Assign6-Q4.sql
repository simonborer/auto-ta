-- Assignment 6- Q4
-- Ekta Patel(N01137684)

SET SERVEROUTPUT ON
BEGIN
  IF test_glaccounts_description('Cash')=1 THEN
    DBMS_OUTPUT.PUT_LINE('Account description is already in use');
  ELSE
    DBMS_OUTPUT.PUT_LINE('Account description is available');
  END IF;
END;
/


