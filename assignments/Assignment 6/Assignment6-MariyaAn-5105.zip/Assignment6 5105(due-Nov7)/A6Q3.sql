--Assignment 6, Question 3, Mariya An
CREATE OR REPLACE FUNCTION test_glaccounts_description
(
account_description_test_param general_ledger_accounts.account_description%TYPE
)
RETURN NUMBER
AS
account_number_var general_ledger_accounts.account_number%TYPE;
BEGIN 
SELECT account_number
INTO account_number_var
FROM general_ledger_accounts
WHERE account_description=account_description_test_param;
IF account_number_var IS NOT NULL THEN
RETURN 1;
END IF;
EXCEPTION
WHEN NO_DATA_FOUND THEN
RETURN 0;
END;
