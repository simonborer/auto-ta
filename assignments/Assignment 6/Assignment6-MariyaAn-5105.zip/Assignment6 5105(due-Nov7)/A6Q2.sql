--Assignment 6, Question 2, Mariya An
SET SERVEROUTPUT ON
BEGIN
    insert_glaccount (
    account_number_param => 635,
    account_description_param =>'Software Services');
COMMIT;
EXCEPTION
 WHEN DUP_VAL_ON_INDEX THEN
    DBMS_OUTPUT.PUT_LINE('A DUP_VAL_ON_INDEX error occured');
    ROLLBACK;
 WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE('An unkown exception occurs');
    ROLLBACK;
END;
/