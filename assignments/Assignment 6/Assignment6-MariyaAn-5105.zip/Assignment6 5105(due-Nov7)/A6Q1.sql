--Assignment 6, Question 1, Mariya An

CREATE OR REPLACE PROCEDURE insert_glaccount
(
   account_number_param general_ledger_accounts.account_number%TYPE,
   account_description_param general_ledger_accounts.account_description%TYPE
)
AS
BEGIN
INSERT INTO general_ledger_accounts
VALUES (account_number_param, account_description_param);
COMMIT;
END;
/

CALL insert_glaccount (634, 'Internet Services'); 
