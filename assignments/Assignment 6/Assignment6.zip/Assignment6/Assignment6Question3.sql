CREATE OR REPLACE FUNCTION test_glaccounts_description(
    account_description_param general_ledger_accounts.account_description%TYPE
)
RETURN NUMBER
AS
    acc_description_flag NUMBER;
BEGIN
    SELECT 1
    INTO acc_description_flag
    FROM general_ledger_accounts
    WHERE account_description = account_description_param;
    
    RETURN acc_description_flag;
    
    EXCEPTION WHEN NO_DATA_FOUND THEN
        acc_description_flag := 0;
        RETURN acc_description_flag;
END;



