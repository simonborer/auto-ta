SET SERVEROUTPUT ON;
DECLARE
    description_check NUMBER;
BEGIN
    DBMS_OUTPUT.PUT_LINE('Checking description Accounting');
    description_check:= test_glaccounts_description('Accounting');
    
    IF description_check=1 THEN
        DBMS_OUTPUT.PUT_LINE('Account description is already in use.');
    ELSIF description_check=0 THEN
    DBMS_OUTPUT.PUT_LINE('Account description is avaliable.');
    END IF;
    
    DBMS_OUTPUT.PUT_LINE('Checking description Car Expense');
    description_check:= test_glaccounts_description('Car Expense');
    
    IF description_check=1 THEN
    DBMS_OUTPUT.PUT_LINE('Account description is already in use.');
    ELSIF description_check=0 THEN
    DBMS_OUTPUT.PUT_LINE('Account description is avaliable.');
    END IF;
END;