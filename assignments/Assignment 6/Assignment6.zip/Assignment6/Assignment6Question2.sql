SET SERVEROUTPUT ON;

BEGIN
    insert_glaccount(591, 'Accounting');
EXCEPTION
    WHEN DUP_VAL_ON_INDEX THEN
        DBMS_OUTPUT.PUT_LINE('A DUP_VAL_ON_INDEX error occured.');
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('An unknown error occured.');
END;