-- Assignment 6 Question 1 Jenna Greenberg
CREATE OR REPLACE PROCEDURE insert_glaacount
(
    account_number_param NUMBER,
    account_description_param   VARCHAR2
)

AS
BEGIN
    INSERT INTO general_ledger_accounts (account_number, account_description)
    VALUES (account_number_param,account_description_param);
END;
/

CALL insert_glaacount(111,'Test Test.');
