-- Assignment 6 Question 2 Jenna Greenberg

SET SERVEROUTPUT ON
BEGIN
    insert_glaacount(100,'New Test');
EXCEPTION
WHEN DUP_VAL_ON_INDEX THEN
DBMS_OUTPUT.PUT_LINE('A DUP_VAL_ON_INDEX error occured.');
WHEN OTHERS THEN
DBMS_OUTPUT.PUT_LINE('An unknown exception occured.');
END;
/
    