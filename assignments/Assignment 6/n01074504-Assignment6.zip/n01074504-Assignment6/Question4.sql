-- Assignment 6 Question 4 Jenna Greenberg


SET SERVEROUTPUT ON;

DECLARE new_var NUMBER;

BEGIN

SELECT  test_glaacounts_description('&account_description')
INTO new_var
FROM dual;
IF (new_var = 1)
THEN
DBMS_OUTPUT.PUT_LINE('Account description is already in use.');
ELSE
DBMS_OUTPUT.PUT_LINE('Account description is available.');
END IF;
END;
/
