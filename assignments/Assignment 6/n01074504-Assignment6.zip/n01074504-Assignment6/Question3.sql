-- Assignment 6 Question 3 Jenna Greenberg

CREATE OR REPLACE FUNCTION test_glaacounts_description
( 
    gla_account_description_param VARCHAR2
)

RETURN NUMBER
AS
    account_description_var NUMBER;
BEGIN
    SELECT 1
    INTO account_description_var
    FROM general_ledger_accounts
    WHERE account_description = gla_account_description_param;
    RETURN account_description_var;
EXCEPTION
    WHEN no_data_found THEN
    account_description_var := 0;
    RETURN account_description_var;
END;
/