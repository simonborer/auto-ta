
ALTER TABLE department_students
ADD student_number number;