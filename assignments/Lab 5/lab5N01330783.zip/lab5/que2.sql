INSERT INTO department_students(student_id,department,college,city)
VALUES(1,'electronics','kec',DEFAULT);

INSERT INTO department_students(student_id,department,college,city)
VALUES  (2,'arts','yya',DEFAULT);

INSERT INTO department_students(student_id,department,college,city)
VALUES  (3,'science','abc',DEFAULT);


--table2
INSERT INTO personal_info_students(personal_id,student_id,First_name,Last_name)
VALUES(10,1,'danny','young');

INSERT INTO personal_info_students(personal_id,student_id,First_name,Last_name)
VALUES(11,2,'lars','holand');

INSERT INTO personal_info_students(personal_id,student_id,First_name,Last_name)
VALUES(12,3,'maria','gordon');


--3 table
INSERT INTO employee_students(department_id ,employee_id,start_date,postalcode) 
VALUES(1,1,TO_DATE('15-FEB-20','DD-MON-RR'),'m9w4v4');

INSERT INTO employee_students(department_id ,employee_id,start_date,postalcode) 
VALUES(2,2,TO_DATE('14-FEB-20','DD-MON-RR'),'m9p4v4');

INSERT INTO employee_students(department_id ,employee_id,start_date,postalcode) 
VALUES(3,3,TO_DATE('16-FEB-20','DD-MON-RR'),'m9q4v4');
