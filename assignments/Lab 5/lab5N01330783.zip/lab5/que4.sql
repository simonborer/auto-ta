--5

ALTER TABLE personal_info_students
RENAME TO personal