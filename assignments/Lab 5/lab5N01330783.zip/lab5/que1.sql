--jetalbahen tandel

CREATE TABLE department_students 
( 
    student_id   NUMBER(6) CONSTRAINT department_student_student_id_pk PRIMARY KEY,
    department   VARCHAR2(15) NOT NULL, 
    college      VARCHAR2(15),
    city         VARCHAR2(15) DEFAULT 'PUNE'
)


CREATE TABLE personal_info_students 
( 
     personal_id   NUMBER(6)  PRIMARY KEY,
    student_id     NUMBER(6)  CONSTRAINT personal_info_student_student_id_fk REFERENCES department_students(student_id), 
    First_name      VARCHAR2(15),
    Last_name        VARCHAR2(15) 
)


CREATE TABLE employee_students 
( 
    department_id   NUMBER(6)  PRIMARY KEY,
    employee_id    NUMBER(6)  CONSTRAINT employee_student_employee_id_fk REFERENCES department_students(student_id), 
    start_date      DATE,
    postalcode       CHAR(6) 
)

