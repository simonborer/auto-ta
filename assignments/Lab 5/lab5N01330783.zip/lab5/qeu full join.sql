--3
SELECT department,First_name,employee_id
FROM department_students s
FULL JOIN personal_info_students p
ON s.student_id=p.student_id
FULL JOIN employee_students e
ON s.student_id=e.employee_id

