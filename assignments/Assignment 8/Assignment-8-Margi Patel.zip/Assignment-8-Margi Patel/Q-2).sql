-- Margi Patel
--n01333713
--Assignment-8


--Question-2
--Referance From Simon's Table

SET SERVEROUTPUT ON;

--Declaring Variables

DECLARE
    --Declaring variables for 20% Discount on Price
    
    week_days VARCHAR(25);
    
    weekly_20_discounted_item VARCHAR2(25);
    item_20_discounted_price NUMBER(4,2);
    
    weekly_10_1_discounted_item VARCHAR2(25);
    item_10_1_discounted_price NUMBER(4,2);
    
    weekly_10_2_discounted_item VARCHAR2(25);
    item_10_2_discounted_price NUMBER(4,2);
    

--Code

BEGIN 

    SELECT item_id, item_name, price FROM bakery_items ORDER BY RANDOM();
    weekly_20_discounted_item := item_name;
    
    SELECT item_id, item_name, price FROM bakery_items ORDER BY RANDOM();
    weekly_10_1_discounted_item := item_name;
    
    SELECT item_id, item_name, price FROM bakery_items ORDER BY RANDOM();
    weekly_10_2_discounted_item := item_name;
    
    SELECT RANDOM(item_id)
    INTO item_20_discounted_price
    FROM bakery_items;
    
    SELECT RANDOM(item_id)
    INTO item_10_1_discounted_price
    FROM bakery_items;
    
    SELECT RANDOM(item_id)
    INTO item_10_2_discounted_price
    FROM bakery_items;
    
    item_20_discounted_price := price * 0.8;
    
    item_10_1_discounted_price := price * 0.9;
    
    item_10_2_discounted_price := price * 0.9;
    
    
    IF EXTRACT(DAY FROM SYSDATE) >= 1 AND EXTRACT(DAY FROM SYSDATE) <= 7 THEN
        DBMS_OUTPUT.PUT_LINE('This weeks special: ' || weekly_20_discounted_item || ' is only ' || item_20_discounted_price );
        DBMS_OUTPUT.PUT_LINE('Take 10% off' || weekly_10_1_discounted_item || item_10_1_discounted_price || 'and' || weekly_10_2_discounted_item || item_10_2_discounted_price );
        DBMS_OUTPUT.PUT_LINE('Check out our everyday low prices:' || item_name || 'and' || price );
        
    ELSIF EXTRACT(DAY FROM SYSDATE) >= 8 AND EXTRACT(DAY FROM SYSDATE) <= 14 THEN
        DBMS_OUTPUT.PUT_LINE( 'This weeks special: ' || weekly_20_discounted_item || ' is only ' || item_20_discounted_price );
        DBMS_OUTPUT.PUT_LINE('Take 10% off' || weekly_10_1_discounted_item || item_10_1_discounted_price || 'and' || weekly_10_2_discounted_item || item_10_2_discounted_price );
        DBMS_OUTPUT.PUT_LINE('Check out our everyday low prices:' || item_name || 'and' || price );
         
    ELSIF EXTRACT(DAY FROM SYSDATE) >= 15 AND EXTRACT(DAY FROM SYSDATE) <= 21 THEN
        DBMS_OUTPUT.PUT_LINE( 'This weeks special: ' || weekly_20_discounted_item || ' is only ' || item_20_discounted_price );
        DBMS_OUTPUT.PUT_LINE('Take 10% off' || weekly_10_1_discounted_item || item_10_1_discounted_price || 'and' || weekly_10_2_discounted_item || item_10_2_discounted_price );
        DBMS_OUTPUT.PUT_LINE('Check out our everyday low prices:' || item_name || 'and' || price );
        
    ELSE
    DBMS_OUTPUT.PUT_LINE();
    END IF;
    
END;
/
    
    