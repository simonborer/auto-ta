-- Margi Patel
--n01333713
--Assignment-8


--Question-1
--AS Per Simon's DataTable Referance
--store procedure to insert new bakery_items

CREATE OR REPLACE PROCEDURE insert_into_bakery_items
(
    item_id_param NUMBER,
    item_name_param VARCHAR,
    price_param NUMBER,
    cost_of_ingredients_param NUMBER,
    baking_time_param NUMBER,
    prep_time_param NUMBER,
    oven_space_param NUMBER,
    temp_param NUMBER
)

AS

BEGIN

INSERT INTO bakery_items
VALUES(item_id_param,item_name_param,price_param,cost_of_ingredients_param,baking_time_param,prep_time_param,oven_space_param,temp_param);

    COMMIT;
EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
END;
/

CALL insert_into_bakery_items(1,'cinamon bun',5,10,1,2,9,5); --without error

CALL insert_into_bakery_items(1,'cinamon bun',5,'sugar',10,1,2,9,5); --with incosistant datatype error Message



    
    
    
    
    
    
    