SET SERVEROUTPUT ON;
CREATE OR REPLACE PROCEDURE insert_food_item
(
    food_id_input food.food_id%TYPE,
    food_name_input food.food_name%TYPE,
    food_type_input food.food_type%TYPE,
    baking_tempurature_input food.baking_temperature%TYPE,
    baking_time_input food.baking_time_in_min%TYPE,
    baking_prep_input food.baking_prep_time%TYPE,
    required_oven_space_input food.required_oven_space%TYPE,
    cost_of_labour_input food.cost_of_labour%TYPE,
    cost_of_ingredients_input food.cost_of_ingredients%TYPE,
    price_input food.price%TYPE,
    discount_id_input food.discount_id%TYPE
)
IS
BEGIN
    INSERT INTO food
    VALUES(food_id_input, food_name_input, food_type_input, baking_tempurature_input, baking_time_input, baking_prep_input,
    required_oven_space_input, cost_of_labour_input, cost_of_ingredients_input, price_input, discount_id_input);
    COMMIT;
EXCEPTION 
WHEN DUP_VAL_ON_INDEX THEN
     DBMS_OUTPUT.PUT_LINE('Not allowed duplicate values');
WHEN INVALID_NUMBER THEN
     DBMS_OUTPUT.PUT_LINE('Value must be a number.');
WHEN OTHERS THEN
     DBMS_OUTPUT.PUT_LINE('An unknown error occured.');
END;


/*-------DISCOUNTS
INSERT INTO DISCOUNT
    VALUES ('1', '20', TO_DATE('18/11/2018', 'DD/MM/YYYY'), TO_DATE('24/11/2018', 'DD/MM/YYYY'));
INSERT INTO DISCOUNT
    VALUES ('2', '10', TO_DATE('18/11/2018', 'DD/MM/YYYY'), TO_DATE('24/11/2018', 'DD/MM/YYYY'));
INSERT INTO DISCOUNT
    VALUES ('3', '10', TO_DATE('25/11/2018', 'DD/MM/YYYY'), TO_DATE('02/12/2018', 'DD/MM/YYYY'));
INSERT INTO DISCOUNT
    VALUES ('4', '20', TO_DATE('25/11/2018', 'DD/MM/YYYY'), TO_DATE('02/12/2018', 'DD/MM/YYYY'));
INSERT INTO DISCOUNT
    VALUES ('5', '10', TO_DATE('09/12/2018', 'DD/MM/YYYY'), TO_DATE('16/12/2018', 'DD/MM/YYYY'));
INSERT INTO DISCOUNT
    VALUES ('6', '10', TO_DATE('09/12/2018', 'DD/MM/YYYY'), TO_DATE('16/12/2018', 'DD/MM/YYYY'));

*/

/*Food*/
CALL insert_food_item(1, 'Flatbread', 'Bread', 400, 10, 20, 1, 5, 1, 5, 1);
CALL insert_food_item(2, 'Sourdough Loaf', 'Bread', 400, 20, 4, 2, 10, 2, 2, 2);
CALL insert_food_item(3, 'Cornbread', 'Bread', 400, 10, 30, 1, 5, 1, 3, 2);
CALL insert_food_item(4, 'Cappuccino', 'Coffee', NULL, NULL, NULL, NULL, 1, 1, 2, NULL);
CALL insert_food_item(5, 'Espresso', 'Coffee', NULL, NULL, NULL, NULL, 1, 1, 1, NULL);
CALL insert_food_item(6, 'Americano', 'Coffee', NULL, NULL, NULL, NULL, 1, 1, 1, NULL);

/*------------------------------------------
SELECT * 
FROM discount

SELECT * 
FROM food 

SELECT * 
FROM food f
JOIN discount d
USING(discount_id)
WHERE SYSDATE BETWEEN start_date AND end_date
*/


