CREATE TABLE employee
(
    employee_id  NUMBER(6) PRIMARY KEY,
    employee_first VARCHAR2(35),
    employee_last VARCHAR2(35),
    employee_position VARCHAR2(7) CHECK (UPPER(employee_position) IN ('CASHIER', 'BAKER')),
    hourly_wage NUMBER(4,2),
    scheduled_weekly_hours NUMBER(4, 2) CHECK(scheduled_weekly_hours BETWEEN 25 AND 44)
)

CREATE TABLE shift
(
    shift_id NUMBER(6) PRIMARY KEY, 
    employee_id NUMBER(6) REFERENCES employee(employee_id),
    schedule_id NUMBER(6) REFERENCES schedule(schedule_id),
    start_time TIMESTAMP,
    end_time TIMESTAMP,
    total_hours NUMBER(4, 2) CHECK(total_hours BETWEEN 4 AND 8)
)

CREATE TABLE schedule
(
    schedule_id NUMBER(6) PRIMARY KEY,
    store_id NUMBER(6) REFERENCES bakery(store_id),
    start_date DATE,
    end_date DATE,
    total_week_hours NUMBER(4,2)
)

CREATE TABLE bakery
(
    store_id NUMBER(6) PRIMARY KEY,
    store_name VARCHAR2(35),
    address VARCHAR2(35),
    oven_space NUMBER(10, 2),
    revenue NUMBER(20, 2),
    menu_id NUMBER(6) REFERENCES menu(menu_id)
)

CREATE TABLE transactions
(
    transaction_id NUMBER(6) PRIMARY KEY,
    store_id  NUMBER(6) REFERENCES bakery(store_id),
    food_id  NUMBER(6) REFERENCES food(food_id),
    transaction_date DATE
)

CREATE TABLE food
(
    food_id NUMBER(6) PRIMARY KEY,
    food_name VARCHAR2(35),
    food_type VARCHAR2(35),
    baking_temperature NUMBER(5,2),
    baking_time_in_min NUMBER(4,2),
    baking_prep_time NUMBER(10,2),
    required_oven_space NUMBER(5,2),
    cost_of_labour NUMBER(5,2),
    cost_of_ingredients NUMBER(5,2)
)

CREATE TABLE menu
(
    menu_id NUMBER(6) PRIMARY KEY,
    food_id NUMBER(6) REFERENCES food(food_id),
    price NUMBER(5,2), 
    discount_id NUMBER(6) DEFAULT NULL REFERENCES discount(discount_id)
)

CREATE table discount
(
    discount_id NUMBER(6) PRIMARY KEY,
    food_id NUMBER(6) REFERENCES food(food_id),
    discount_percent NUMBER(2),
    start_date DATE,
    end_date DATE
)



