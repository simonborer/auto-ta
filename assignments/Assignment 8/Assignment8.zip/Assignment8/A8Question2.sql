SET SERVEROUTPUT ON;
DECLARE
CURSOR char_cursor IS 
    SELECT food_name, price, discount_percent, start_date, end_date
    FROM food f
    LEFT JOIN discount d
    USING(discount_id)
    WHERE SYSDATE BETWEEN start_date AND end_date OR discount_ID IS NULL
    ORDER BY discount_percent;
BEGIN
FOR char_row IN char_cursor LOOP 
    IF (char_row.discount_percent = 20) THEN 
        DBMS_OUTPUT.PUT_LINE('This weeks special with 20% off: ' || char_row.food_name || ' is only $'|| char_row.price*0.8 || '!');
    ELSIF (char_row.discount_percent = 10) THEN 
        DBMS_OUTPUT.PUT_LINE('Take 10% off ' || char_row.food_name || '. It is only $'|| char_row.price*0.9 || '!');
    ELSE
        DBMS_OUTPUT.PUT_LINE('Other menu items we have are: ' || char_row.food_name || ' $'|| char_row.price);
    END IF;
END LOOP;
END;




