CREATE OR REPLACE PROCEDURE insert_bakery_item
(
   product_id_param bakery_products.product_id%TYPE,
   product_type_param bakery_products.product_type%TYPE,
   product_description_param bakery_products.product_description%TYPE
)
AS
BEGIN
INSERT INTO bakery_products
VALUES (product_id_param, product_type_param, product_description_param );
COMMIT;
EXCEPTION
 WHEN DUP_VAL_ON_INDEX THEN
    DBMS_OUTPUT.PUT_LINE('A DUP_VAL_ON_INDEX error occured');
    ROLLBACK;
 WHEN NO_DATA_FOUND THEN
    DBMS_OUTPUT.PUT_LINE('No Data found');
 WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE('An unkown exception occurs');
    ROLLBACK;
END;
/
