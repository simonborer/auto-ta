--Mariya An, Assignment 8, Question 2
SET SERVEROUTPUT ON;
DECLARE
CURSOR bakery_menu_cursor
IS SELECT product_id, product_type, menu_item_regular_price AS price
FROM bakery_menu;

major_discount NUMBER;
mainor_discount1 NUMBER;
mainor_discount2 NUMBER;
product_type_major bakery_menu.product_type%TYPE;
product_type_minor1 bakery_menu.product_type%TYPE;
product_type_minor2 bakery_menu.product_type%TYPE;
price_major NUMBER;
price_minor1 NUMBER;
price_minor2 NUMBER;
BEGIN
   SELECT  major_discount_minus20,minor_discount1_minus10,minor_discount2_minus10
   INTO major_discount, minor_discount1, minor_discount2
   FROM bakery_discounts
   WHERE TO_CHAR(SYSDATE,'IW')=TO_CHAR(week_starting, 'IW');
   
   SELECT product_type, menu_item_regular_price
   INTO product_type_major, price_major
   FROM bakery_menu
   WHERE major_discount=product_id;
   
   SELECT product_type, menu_item_regular_price
   INTO product_type_minor1, price_minor1
   FROM bakery_menu
   WHERE minor_discount1=product_id;
   
   SELECT product_type, menu_item_regular_price
   INTO product_type_minor2, price_minor2
   FROM bakery_menu
   WHERE minor_discount2=product_id;

    DBMS_OUTPUT.PUT_LINE('This weeks special:' || product_type_major ||' '|| 'is only' ||' '||'$'||price_major*0.8||'!');
    DBMS_OUTPUT.PUT_LINE('Take 10% off ' || product_type_mainor1 ||' ' || price_minor1*0.9 || 'and' || product_type_mainor2||' '|| price_minor2*0.9);
   
   FOR bakery_menu_row IN bakery_menu_cursor
   LOOP IF product_id NOT IN (major_discount, minor_discount1, minor_discount2)
   THEN
    DBMS_OUTPUT.PUT_LINE('Check out our everyday low prices: ' || bakery_menu_row.product_type||' '||'$' ||' '|| 'is only' ||' '||'$'||bakery_menu_row.price||'!');
    END IF;
    END LOOP;
END;



