/* Assignment 8 - Tables File
   Raymond Giang
   n01304390
   
   The following file is the script to create the tables for my version of the bakery scenario */

/* Note: These tables are based on my submission for Assignment 7, with changed made based on our class
   discussion the previous week */

CREATE TABLE bakery_employees (
    employee_id         NUMBER
        CONSTRAINT bakery_employees_employee_id_pk PRIMARY KEY,
    employee_fname      VARCHAR2(50)
        CONSTRAINT bakery_employees_employee_fname_nn NOT NULL,
    employee_lname      VARCHAR2(50)
        CONSTRAINT bakery_employees_employee_lname_nn NOT NULL,
    employee_type       VARCHAR2(50)
        CONSTRAINT bakery_employees_employee_type_ck CHECK
            (LOWER(employee_type) IN ('baker', 'cashier'))
        CONSTRAINT bakery_employees_employee_type_nn NOT NULL,
    hours_scheduled     NUMBER
);

CREATE TABLE bakery_stores (
    store_id         NUMBER
        CONSTRAINT bakery_stores_store_id_pk PRIMARY KEY,
    store_name       VARCHAR2(100)
        CONSTRAINT bakery_stores_store_name_nn NOT NULL,
    store_address    VARCHAR2(100)
        CONSTRAINT bakery_stores_store_address_nn NOT NULL,
    open_time        VARCHAR(20)   
        DEFAULT '09:00:00'
        CONSTRAINT bakery_stores_open_time_nn NOT NULL
        CONSTRAINT bakery_stores_open_time_ck CHECK
            (open_time LIKE '__:__:__'),
    close_time       VARCHAR(20)
        DEFAULT '17:00:00'
        CONSTRAINT bakery_stores_close_time_nn NOT NULL,
        CONSTRAINT bakery_stores_close_time_ck CHECK
            (close_time LIKE '__:__:__'),
    ovens_available  NUMBER
        DEFAULT 1
        CONSTRAINT bakery_stores_ovens_available_nn NOT NULL
);

CREATE TABLE bakery_shifts (
    shift_id            NUMBER
        CONSTRAINT bakery_shifts_shift_id_pk PRIMARY KEY,
    employ_type_req     VARCHAR2(50)
        CONSTRAINT bakery_shifts_employ_type_req_ck CHECK
            (LOWER(employ_type_req) IN ('baker', 'cashier'))
        CONSTRAINT bakery_shifts_employ_type_req_nn NOT NULL,
    store_id            NUMBER
        CONSTRAINT bakery_shifts_store_id_fk REFERENCES bakery_stores(store_id),
    day_of_week         VARCHAR(20)
        CONSTRAINT bakery_shifts_day_of_week_nn NOT NULL,
    start_time          VARCHAR(20)
        CONSTRAINT bakery_shifts_start_time_nn NOT NULL
        CONSTRAINT bakery_shifts_start_time_ck CHECK
            (start_time LIKE '__:__:__'),
    end_time            VARCHAR(20)
        CONSTRAINT bakery_shifts_end_time_nn NOT NULL
        CONSTRAINT bakery_shifts_end_time_ck CHECK
            (end_time LIKE '__:__:__')
);

CREATE TABLE shift_availability (
    availability_id         NUMBER
        CONSTRAINT shift_availability_availability_id_pk PRIMARY KEY,
    employee_id             NUMBER
        CONSTRAINT shift_availability_employee_id_fk REFERENCES bakery_employees(employee_id),
    shift_id                NUMBER
        CONSTRAINT shift_availability_shift_id_fk REFERENCES bakery_shifts(shift_id)
);

CREATE TABLE food_items (
    food_id             NUMBER
        CONSTRAINT food_items_food_id_pk PRIMARY KEY,
    food_name           VARCHAR2(50)
        CONSTRAINT food_items_food_name_nn NOT NULL,
    food_type           VARCHAR2(50)
        CONSTRAINT food_items_food_type_nn NOT NULL,
    ingredients_cost    NUMBER(*,2)
        CONSTRAINT food_items_ingredients_cost_nn NOT NULL,
    prep_time           NUMBER,
    bake_time           NUMBER,
    bake_temp           NUMBER,
    oven_space          NUMBER,
    sell_price          NUMBER(*,2)
        CONSTRAINT food_items_sell_price_nn NOT NULL
);

CREATE TABLE bakery_discounts (
    cycle_number            NUMBER      
        CONSTRAINT bakery_discounts_cycle_number_pk PRIMARY KEY,
    major_discount_id          NUMBER
        CONSTRAINT bakery_discounts_major_discount_id_fk REFERENCES food_items(food_id),
    minor_discount_id_one      NUMBER
        CONSTRAINT bakery_discounts_minor_discount_id_one_fk REFERENCES food_items(food_id),
    minor_discount_id_two      NUMBER
        CONSTRAINT bakery_discounts_minor_discount_id_two_fk REFERENCES food_items(food_id)
);

CREATE TABLE bakery_sales (
    sale_id         NUMBER
        CONSTRAINT bakery_sales_sale_id_pk PRIMARY KEY,
    food_id         NUMBER
        CONSTRAINT bakery_sales_food_id_fk REFERENCES food_items(food_id),
    store_id        NUMBER
        CONSTRAINT bakery_sales_store_id_fk REFERENCES bakery_stores(store_id),
    sale_date       DATE
        DEFAULT SYSDATE,
    sale_price      NUMBER(*,2)
        CONSTRAINT bakery_sales_sale_price_nn NOT NULL,
    qty_sold        NUMBER
        DEFAULT 1
        CONSTRAINT bakery_sales_qty_sold_nn NOT NULL
);
