/* Assignment 8 - Answers File
   Raymond Giang
   n01304390
   
   This file contains my answers to the Assignment 8 Questions */
   
/* 1. Create a stored procedure to add new items to the menu.
   Make sure to handle invalid data types with proper error messages. */
   
SET SERVEROUTPUT ON;
   
CREATE OR REPLACE PROCEDURE insert_food_item
(
    food_id_insert               food_items.food_id%TYPE,
    food_name_insert             food_items.food_name%TYPE,
    food_type_insert             food_items.food_type%TYPE,
    ingredients_cost_insert      food_items.ingredients_cost%TYPE,
    prep_time_insert             food_items.prep_time%TYPE,
    bake_time_insert             food_items.bake_time%TYPE,
    bake_temp_insert             food_items.bake_temp%TYPE,
    oven_space_insert            food_items.oven_space%TYPE,
    sell_price_insert            food_items.sell_price%TYPE
)
AS
BEGIN
    INSERT INTO food_items(food_id, food_name, food_type, ingredients_cost, prep_time, bake_time, bake_temp,
        oven_space, sell_price)
    VALUES(food_id_insert, food_name_insert, food_type_insert, ingredients_cost_insert, prep_time_insert, bake_time_insert,
        bake_temp_insert, oven_space_insert, sell_price_insert);
    COMMIT;
EXCEPTION
    WHEN DUP_VAL_ON_INDEX THEN
        DBMS_OUTPUT.PUT_LINE('The entry contains a duplicate value on column that requires a unique value');
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('An unknown error has occurred');
END;
/

CREATE SEQUENCE food_id_seq;
SET SERVEROUTPUT ON;

BEGIN
    insert_food_item(food_id_seq.NEXTVAL, 'White Bread', 'Bread', 1, 5, 25, 350, 2, 5);
    insert_food_item(food_id_seq.NEXTVAL, 'Bagel', 'Bread', 1, 8, 25, 350, 2, 5.50);
    insert_food_item(food_id_seq.NEXTVAL, 'Banana Bread', 'Bread', 2.25, 10, 30, 350, 2, 6);
    insert_food_item(food_id_seq.NEXTVAL, 'Cheese Bread', 'Bread', 3, 10, 35, 350, 2, 7.50);
    insert_food_item(food_id_seq.NEXTVAL, 'Croissant', 'Pastry', 1, 10, 25, 400, 2, 3);
    insert_food_item(food_id_seq.NEXTVAL, 'Apple Pie', 'Pastry', 10.50, 20, 55, 450, 5, 18.25);
    insert_food_item(food_id_seq.NEXTVAL, 'Pecan Tart', 'Pastry', 8.25, 15, 50, 450, 1, 10.25);
    insert_food_item(food_id_seq.NEXTVAL, 'Cinammon Roll', 'Pastry', 3.75, 20, 35, 400, 3, 6);
    insert_food_item(food_id_seq.NEXTVAL, 'Scone', 'Pastry', 2, 5, 30, 350, 1, 4.25);
    insert_food_item(food_id_seq.NEXTVAL, 'Custard Tart', 'Pastry', 3, 15, 45, 400, 1, 5.75);
    insert_food_item(food_id_seq.NEXTVAL, 'Coffee', 'Coffee', 1, 5, 0, 0, 0, 3.25);
END;
/

/* 2. Create an anonymous SQL block (in an .sql file).
      The file should output to the script output pane of SQL Developer.
      It should say...
      "This week's special: [item] is only [price discounted 20%]!
      "Take 10% off [item] ([price discounted 10%]) and [item] ([price discounted 10%])!"
      "Check out our everyday low prices:"
      [One line for each other item, showing the item name and price]
      The discounts should be based off of the current date. If you were to run the script a week from now, 
      different items would be discounted. */

/* My version of the discounts table contains a cycle of 5 "sales"
   Which cycle is active depends on which week in the year it currently is
   The cycle will repeat once all 5 cycles have passed */
INSERT INTO bakery_discounts(cycle_number, major_discount_id, minor_discount_id_one, minor_discount_id_two)
    VALUES (0, 3, 5, 7);
INSERT INTO bakery_discounts(cycle_number, major_discount_id, minor_discount_id_one, minor_discount_id_two)
    VALUES (1, 8, 2, 6);
INSERT INTO bakery_discounts(cycle_number, major_discount_id, minor_discount_id_one, minor_discount_id_two)
    VALUES (2, 9, 4, 7);
INSERT INTO bakery_discounts(cycle_number, major_discount_id, minor_discount_id_one, minor_discount_id_two)
    VALUES (3, 10, 1, 5);
INSERT INTO bakery_discounts(cycle_number, major_discount_id, minor_discount_id_one, minor_discount_id_two)
    VALUES (4, 7, 9, 11);

SET SERVEROUTPUT ON;

DECLARE
    major_discount_food_id            food_items.food_id%TYPE;
    major_discount_food_name          food_items.food_name%TYPE;
    major_discount_food_price         food_items.sell_price%TYPE;
    minor_discount_one_food_id        food_items.food_id%TYPE;
    minor_discount_one_food_name      food_items.food_name%TYPE;
    minor_discount_one_food_price     food_items.sell_price%TYPE;
    minor_discount_two_food_id        food_items.food_id%TYPE;
    minor_discount_two_food_name      food_items.food_name%TYPE;
    minor_discount_two_food_price     food_items.sell_price%TYPE;
    
    CURSOR food_items_cursor IS 
        SELECT food_id, food_name, sell_price
        FROM food_items
        WHERE food_id NOT IN (major_discount_food_id, minor_discount_one_food_id, minor_discount_two_food_id)
        ORDER BY food_id;
BEGIN
    /* The following 3 select queries retrieve the information about the discounted items in the current
       "sales" cycle */
    
    SELECT food_name, ROUND(sell_price*0.80, 2), fi.food_id
    INTO major_discount_food_name, major_discount_food_price, major_discount_food_id
    FROM bakery_discounts bd
    JOIN food_items fi
    ON bd.major_discount_id = fi.food_id
    WHERE cycle_number = MOD(TO_CHAR(SYSDATE, 'IW'), 5);
    
    SELECT food_name, ROUND(sell_price*0.90, 2), fi.food_id
    INTO minor_discount_one_food_name, minor_discount_one_food_price, minor_discount_one_food_id
    FROM bakery_discounts bd
    JOIN food_items fi
    ON bd.minor_discount_id_one = fi.food_id
    WHERE cycle_number = MOD(TO_CHAR(SYSDATE, 'IW'), 5);
    
    SELECT food_name, ROUND(sell_price*0.90, 2), fi.food_id
    INTO minor_discount_two_food_name, minor_discount_two_food_price, minor_discount_two_food_id
    FROM bakery_discounts bd
    JOIN food_items fi
    ON bd.minor_discount_id_two = fi.food_id
    WHERE cycle_number = MOD(TO_CHAR(SYSDATE, 'IW'), 5);
    
    /* First the information on the discounted items will be displayed, then it will loop through all food items
       not included in the discounts and display information about them */
    
    DBMS_OUTPUT.PUT_LINE('This week''s special: ' || major_discount_food_name || ' is only $' 
        || major_discount_food_price || '!');
    DBMS_OUTPUT.PUT_LINE('Take 10% off ' || minor_discount_one_food_name || ' ($' || minor_discount_one_food_price || 
        ') and ' || minor_discount_two_food_name || ' ($' || minor_discount_two_food_price || ').');
    DBMS_OUTPUT.PUT_LINE(CHR(10) || 'Check out our everyday low prices:');
    
    FOR food_item IN food_items_cursor LOOP
        DBMS_OUTPUT.PUT_LINE(food_item.food_name || ' is only $' || food_item.sell_price || '!');
    END LOOP;
END;
/
