CREATE TABLE bakery_locations
(
    location_id         NUMBER(3)      PRIMARY KEY,
    address             VARCHAR2(30)   NOT NULL,
    opening_hour        VARCHAR2(4),
    closing_hour        VARCHAR2(4),
    cashiers_per_shift  NUMBER(2),
    bakers_per_shift    NUMBER(2),
    oven_racks          NUMBER(2)
);

CREATE TABLE bakery_employees
(
    employee_id         NUMBER (6)      PRIMARY KEY,
    employee_name       VARCHAR2(30),
    hourly_rate         NUMBER(5)       DEFAULT  '15.00',
    employee_type       VARCHAR2(10)    CHECK (employee_type='baker' OR employee_type='cashier'),
    preferred_location  NUMBER (3)      REFERENCES bakery_locations(location_id)
);

CREATE TABLE bakery_items
(
    item_id                 NUMBER(6)   PRIMARY KEY,
    item_name               VARCHAR2(30),
    cost_of_ingredients     NUMBER(4),
    sale_price              NUMBER(4),
    prep_minutes            NUMBER(6),
    bake_minutes            NUMBER(6),
    oven_racks_needed       NUMBER(3),
    items_per_batch         NUMBER(4)
);

CREATE TABLE drink_items
(
    drink_id        NUMBER(6)       PRIMARY KEY,
    drink_name      VARCHAR2(30),
    drink_cost_s    NUMBER(4),
    sale_cost_s     NUMBER(4),
    drink_cost_l    NUMBER(4),
    sale_cost_l     NUMBER(4)
);

CREATE TABLE bakery_food_menu
(
    item_id                 NUMBER(6)       REFERENCES bakery_items(item_id),
    item_name               VARCHAR2(30)    UNIQUE,
    item_price              NUMBER(4),
    weekly_special          VARCHAR2(4)     DEFAULT 'no' CHECK(weekly_special='yes' OR weekly_special='no')  
);

CREATE TABLE bakery_drinks_menu
(
    drink_id         NUMBER(6)      REFERENCES drink_items(drink_id),
    drink_name       VARCHAR2(30)   UNIQUE,
    price_small      NUMBER(4),
    price_large      NUMBER(4),
    weekly_special   VARCHAR2(4)     DEFAULT 'no' CHECK(weekly_special='yes' OR weekly_special='no')  
);

CREATE TABLE bakery_transactions
(
    transaction_id     NUMBER(6)    PRIMARY KEY,
    customer_id        NUMBER(6),
    item_id            NUMBER(6)    REFERENCES bakery_items(item_id),
    drink_id           NUMBER(6)    REFERENCES drink_items(drink_id),
    item_cost          NUMBER(4)    NOT NULL,
    bakery_location    NUMBER(3)    REFERENCES bakery_locations(location_id),
    purchase_date      DATE
);
    
CREATE TABLE baked_goods_x_bakery
(
    BGxB_id     NUMBER(4)   PRIMARY KEY,
    item_id     NUMBER(6)   REFERENCES bakery_itmes(item_id),
    bakery_id   NUMBER(3)   REFERENCES bakery_locations(location_id)
);

CREATE TABLE bakery_schedule 
(
    sched_id    NUMBER(6)   PRIMARY KEY,
    employee_id NUMBER(6)   REFERENCES bakery_employees(employee_id),
    shift_time  NUMBER(6),
    shift_day   DATE,
    location_id NUMBER(3)   REFERENCES bakery_locations(location_id)
);
    