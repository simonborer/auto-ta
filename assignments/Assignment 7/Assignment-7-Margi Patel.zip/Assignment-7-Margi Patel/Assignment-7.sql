--Margi Patel
--Assignment 7
--1

CREATE TABLE bakeries
(
    bakery_id       NUMBER(4) PRIMARY KEY,
    bakery_address  VARCHAR2(40) NOT NULL,
    employee_id     NUMBER(4)
                    CONSTRAINT bakeries_employee_id_fk REFERENCES employees(employee_id)   
            
)

--Margi Patel
--Assignment 7
--2


CREATE TABLE employees
(
    employee_id     NUMBER(4) PRIMARY KEY,
    bakery_id       NUMBER(10)
                    CONSTRAINT employees_bakery_id_fk REFERENCES bakeries(bakery_id),
                    
    
    employee_name   VARCHAR2(30)  NOT NULL,
    employee_role   VARCHAR(10)
                    CONSTRAINT employees_employee_role_ck CHECK(employee_role IN('bakers','cashiers')),
    
    weekly_work_hours    NUMBER(2)
                         CONSTRAINT employees_weekly_work_hours_ck CHECK(weekly_work_hours BETWEEN 25 AND 45),
                         
    shifts          NUMBER(4)
                    CONSTRAINT employees_shifts_ck CHECK(shifts BETWEEN 4 AND 8),
            
    bakery_location  VARCHAR2(10)
)


--Margi Patel
--Assignment 7
--3

CREATE TABLE products
(
    product_id NUMBER(4) PRIMARY KEY,
    product_name VARCHAR(20) NOT NULL,
    product_price NUMBER(4)

)

CREATE TABLE pasteries
(
    product VARCHAR2(20) REFERENCES products(product_id),
    pasteries_id NUMBER(4) PRIMARY KEY,
    pasteries_type VARCHAR(20) NOT NULL,
    pasteries_price NUMBER(4) NOT NULL
)

CREATE TABLE breads
(   
    product VARCHAR2(20) REFERENCES products(product_id),
    bread_id  NUMBER(4) PRIMARY KEY,
    bread_type VARCHAR2(20) NOT NULL,
    bread_price NUMBER(4) NOT NULL
)

CREATE TABLE cost 
(   
    product VARCHAR2(20) REFERENCES products(product_id),
    product_cost NUMBER(10),
    product_matieral NUMBER(10),
    product_labourwork NUMBER(10)
)


--store procedure

CREATE OR REPLACE PROCEDURE update_breads
(
    bread_id_param NUMBER,
    bread_type_param VARCHAR2
    
)
AS

BEGIN

UPDATE breads
SET bread_type = bread_type_param 
WHERE bread_id = bread_id_param;

COMMIT;

EXCEPTION
    WHEN OTHERS THEN ROLLBACK;
END;
/

CALL update_breads(1,'WHOLE WHEAT');
