//Jing Cheng
//n01289618

CREATE TABLE bakery(
  bakery_id NUMBER(6) PRIMARY KEY,
  bakery_name VARCHAR2(20),
  bakery_phone VARCHAR2(11),
  bakery_address VARCHAR2(30)
);

CREATE TABLE staff(
  staff_id NUMBER(6) PRIMARY KEY,
  staff_fname VARCHAR2(10),
  staff_lname VARCHAR2(10),
  staff_role REFERENCES Staff_Role(staff_role_id)
);

CREATE TABLE Staff_Role(
  staff_role_id NUMBER(6) PRIMARY KEY,
  staff_role_name VARCHAR2(15) 
);

CREATE TABLE Shift_Times(
  shift_time_id NUMBER(6) PRIMARY KEY,
  shift_time VARCHAR2(10),
  shift_duration NUMBER(1),
  CONSTRAINT check_shift_duration
  CHECK (shift_duration BETWEEN 4 AND 8)
);

CREATE TABLE Shift(
  shift_id NUMBER(6) PRIMARY KEY,
  staff_id NUMBER(6) REFERENCES staff(staff_id),
  shift_time_id NUMBER(6) REFERENCES Shift_Times(shift_time_id),
  shift_date VARCHAR2(20)
);

CREATE TABLE invoices(
  invoice_id NUMBER(6) PRIMARY KEY,
  total_cost NUMBER(6),
  payment_type VARCHAR2(11)
);

CREATE TABLE menu(
  menu_id NUMBER(6) PRIMARY KEY,
  menu_desc VARCHAR2(30)
);

CREATE TABLE bakery_orders(
  order_id NUMBER(6) PRIMARY KEY,
  order_date VARCHAR2(25),
  order_time VARCHAR2(10),
  staff_id NUMBER(6) REFERENCES staff(staff_id)
);

ALTER TABLE bakery_orders ADD order_menu_item_id NUMBER(6)
ALTER TABLE bakery_orders ADD FOREIGN KEY (order_menu_item_id) REFERENCES Order_Menu_Item(order_menu_item_id)

CREATE TABLE Order_Menu_Item(
  order_menu_item_id NUMBER(6) PRIMARY KEY,
  order_menu_item_quantity NUMBER(2),
  order_id NUMBER(6) REFERENCES bakery_orders(order_id)
);

ALTER TABLE Order_Menu_Item ADD menu_item_id NUMBER(6)
ALTER TABLE Order_Menu_Item ADD FOREIGN KEY (menu_item_id) REFERENCES Menu_Items(menu_item_id)

CREATE TABLE Menu_Items(
  menu_item_id NUMBER(6) PRIMARY KEY,
  menu_item_name VARCHAR2(20),
  menu_item_price NUMBER(6),
  menu_item_ingredient_cost NUMBER(6),
  menu_item_baking_time VARCHAR2(10),
  menu_item_prep_time VARCHAR2(10),
  menu_item_baking_temp VARCHAR2(10),
  menu_item_req_space VARCHAR2(10),
  menu_item_desc VARCHAR2(10),
  menu_id NUMBER(6) REFERENCES menu(menu_id),
  order_menu_item_id NUMBER(6) REFERENCES Order_Menu_Item(order_menu_item_id)
);