CREATE TABLE store_locations (
    location_ID NUMBER(3) PRIMARY KEY,
    location_address VARCHAR(60) NOT NULL,
    location_postal_code VARCHAR(6) NOT NULL
)

CREATE TABLE employee_roles (
    employee_role_ID NUMBER(3) PRIMARY KEY,
    role_name VARCHAR(20) NOT NULL
)

CREATE TABLE employee (
    employee_ID NUMBER(3) PRIMARY KEY,
    employee_fname VARCHAR(30) NOT NULL,
    employee_lname VARCHAR(30) NOT NULL,
    employee_role_ID NUMBER(3) REFERENCES employee_roles(employee_role_ID),
    wage_per_hour NUMBER(3) DEFAULT 13
)

CREATE TABLE employee_shift (
    shift_ID NUMBER(3) PRIMARY KEY,
    employee_id NUMBER(3) REFERENCES employee(employee_ID),
    shift_start_time DATE NOT NULL,
    shift_end_time DATE NOT NULL,
    location_ID NUMBER(3) REFERENCES store_locations(location_ID)
)

CREATE TABLE food_items (
    food_ID NUMBER(3) PRIMARY KEY,
    food_name VARCHAR(30) NOT NULL,
    food_cost NUMBER(10) NOT NULL, --Cost to create the food, not the price for the customers
    food_baking_time NUMBER(3) NOT NULL,
    food_prep_time NUMBER(3) NOT NULL,
    food_baking_temperature NUMBER(3) NOT NULL,
    required_oven_space NUMBER(3) NOT NULL
)


CREATE TABLE drink_items (
   drink_ID NUMBER(3) PRIMARY KEY,
   drink_name VARCHAR(30) NOT NULL,
   drink_cost NUMBER(10) NOT NULL --Cost to create the drink, not the price for the customers.
)

CREATE TABLE food_prices (
    --Prices for customers.
    food_price_id NUMBER(3) PRIMARY KEY,
    food_ID NUMBER(3) REFERENCES food_items(food_id),
    food_price NUMBER(3) NOT NULL
)

CREATE TABLE drink_prices (
    --Prices for customers.
    drink_price_id NUMBER(3) PRIMARY KEY,
    drink_ID NUMBER(3) REFERENCES drink_items(drink_id),
    drink_price NUMBER(3) NOT NULL
)

CREATE TABLE store_menu (
    menu_id NUMBER(3) PRIMARY KEY,
    food_ID NUMBER(3) REFERENCES food_items(food_id),
    drink_ID NUMBER(3) REFERENCES drink_items(drink_id),
    food_price_id NUMBER(3) REFERENCES food_prices(food_price_id),
    --drink_price_id NUMBER(3) REFERENCES drink_prices(drink_price_id),
    location_id NUMBER(3) REFERENCES store_locations(location_id),
    discount_amt NUMBER(2) DEFAULT 0
)


CREATE TABLE customer_food_order (
    --add a column for each food item that the customer purchased.
    food_order_id NUMBER(3) PRIMARY KEY,
    food_price_id NUMBER(3) REFERENCES food_prices(food_price_id)
)

CREATE TABLE customer_drink_order(
    --add a column for each drink item that the customer purchased.
    drink_order_id NUMBER(3) PRIMARY KEY,
    drink_price_id NUMBER(3) REFERENCES drink_prices(drink_price_id)
)


CREATE TABLE store_invoices (
    invoice_id NUMBER(3) PRIMARY KEY,
    invoice_date DATE,
    food_order_id NUMBER(3) REFERENCES customer_food_order(food_order_id),
    drink_order_id NUMBER(3) REFERENCES customer_drink_order(drink_order_id),
    invoice_total NUMBER(10) NOT NULL,
    payment_total NUMBER(10) NOT NULL,
    payment_date DATE NOT NULL,
    location_id NUMBER(3) REFERENCES store_locations(location_id)
)