
--Margi Patel
--n01333713
--week-9
--Q-2



CREATE TABLE my_books
    (
        
        book_id NUMBER(4) PRIMARY KEY,
        title VARCHAR2(20) ,
        genre VARCHAR(20),
        rank NUMBER(4)
        )
        
CREATE TABLE my_movies
    (
        
        movie_id NUMBER(4) PRIMARY KEY,
        title VARCHAR2(20) ,
        genre VARCHAR(20),
        rank NUMBER(4)
        )
        
        
        



CREATE OR REPLACE PROCEDURE insert_into_my_books
(
   
    item_id_param NUMBER,
    title_param VARCHAR2 ,
    genre_param VARCHAR,
    rank_param NUMBER 

)
AS

BEGIN
    
    
    INSERT INTO my_books
    VALUES(item_id_param, title_param, genre_param, rank_param);
    
    
    
    COMMIT;
EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
END;
/

CALL insert_into_my_books( 1, 'Revolution 2020', 'Friction',1);

CALL insert_into_my_books( 2, 'Muranch SQL Part-1', 'Textbook',3);

CALL insert_into_my_books( 3, 'Ramayana', 'Spiritual',2);


--UPDATE my_books 
--SET rank = 2 where book_id = 3;


CREATE OR REPLACE PROCEDURE insert_into_my_movies
(
   
    item_id_movies_param NUMBER,
    title_param VARCHAR2 ,
    genre_param VARCHAR,
    rank_param NUMBER 

)
AS

BEGIN
    
    
    INSERT INTO my_movies
    VALUES(item_id_movies_param, title_param, genre_param, rank_param);
    
    
    
    COMMIT;
EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
END;
/

CALL insert_into_my_movies( 1, 'Twilight Part-1', 'Lovestory',1);

CALL insert_into_my_movies( 2, 'Baby', 'Action',3);

CALL insert_into_my_movies( 3, 'The Gazzi Attack', 'Action',2);


--UPDATE my_movies
--SET rank = 3 WHERE movie_id = 2
