
--Margi Patel
--n01333713
--week-9
--Q-3





--For Books (my_books)
CREATE OR REPLACE FUNCTION get_title_my_books
    (
        rank_param NUMBER
        
  
    )
    
    
RETURN VARCHAR2

AS
    title_param VARCHAR(20);
  
BEGIN 
  SELECT title
  INTO title_param
  FROM my_books
  WHERE rank = rank_param;
  


  RETURN title_param;
END;
/

SELECT get_title_my_books(2) FROM dual;





--For Movies(my_movies)




CREATE OR REPLACE FUNCTION get_title_my_movies
    (
        rank_param NUMBER
        
  
    
    )
    
    
RETURN VARCHAR2

AS
    title_param VARCHAR(20);
  
BEGIN 
  SELECT title
  INTO title_param
  FROM my_movies
  WHERE rank = rank_param;
  


  RETURN title_param;
END;
/

SELECT get_title_my_movies(1) FROM dual;
