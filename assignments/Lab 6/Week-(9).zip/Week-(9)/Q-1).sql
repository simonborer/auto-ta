--Margi Patel
--n01333713
--week-9
--Q-1


CREATE OR REPLACE FUNCTION get_customer_id
    (
        customer_first_param customers.customer_first_name%TYPE,
        customer_last_param customers.customer_last_name%TYPE
  
    
    )
    
    
RETURN NUMBER

AS
    customer_id_var NUMBER;
  
BEGIN 
  SELECT customer_id
  INTO customer_id_var
  FROM customers
  WHERE customer_first_name = customer_first_param AND customer_last_name = customer_last_param;
  


  RETURN customer_id_var;
END;
/

SELECT get_customer_id('Yash','Randall') FROM dual;

