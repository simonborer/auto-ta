CREATE TABLE my_books(
    book_id NUMBER(6) PRIMARY KEY,
    title VARCHAR2(30) NOT NULL,
    genre VARCHAR2(20),
    rank_number NUMBER(6) UNIQUE
);

CREATE TABLE my_movies(
    movie_id NUMBER(6) PRIMARY KEY,
    title VARCHAR2(30) NOT NULL,
    genre VARCHAR2(20),
    rank_number NUMBER(6) UNIQUE
);

CREATE OR REPLACE PROCEDURE insert_movie
(
    movie_id_input my_movies.movie_id%TYPE,
    title_input my_movies.title%TYPE,
    genre_input my_movies.genre%TYPE,
    rank_number my_movies.rank_number%TYPE
)
IS
BEGIN
    INSERT INTO my_movies
    VALUES(movie_id_input, title_input, genre_input, rank_number);
COMMIT;
END;






