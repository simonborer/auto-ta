CREATE OR REPLACE FUNCTION get_balance_due(
    input_invoice_id NUMBER
)
RETURN NUMBER 
AS 
    balance_due NUMBER;
BEGIN
    SELECT invoice_total - (payment_total + credit_total) AS balance_due
    INTO balance_due
    FROM invoices
    WHERE invoice_id = input_invoice_id;
    RETURN balance_due;
END;

