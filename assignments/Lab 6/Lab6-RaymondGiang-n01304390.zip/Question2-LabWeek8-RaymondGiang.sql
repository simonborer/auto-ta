/* Lab Week 8 - Question 2
   Name: Raymond Giang
   Student Number: n01304390 */

/* 2. Create 2 tables, one called my_books, one called my_movies. In each, create a primary key, a column called 'title', 
a column called 'genre', and a column called 'rank'. Then create a stored procedure that can insert a row into either of 
those tables, with the values passed as parameters. Insert at least 3 each of your favourite books and movies into the 
tables using your procedure. */

/* Creating the Tables */

CREATE TABLE my_books(
    book_id       NUMBER
        CONSTRAINT my_books_book_id_pk PRIMARY KEY,
    title         VARCHAR2(30)
        CONSTRAINT my_books_title_nn NOT NULL,
    genre         VARCHAR2(30)
        CONSTRAINT my_books_genre_nn NOT NULL,
    rank          NUMBER
        CONSTRAINT my_books_rank_uk UNIQUE
);

CREATE TABLE my_movies(
    movie_id       NUMBER
        CONSTRAINT my_movies_movie_id_pk PRIMARY KEY,
    title         VARCHAR2(20)
        CONSTRAINT my_movies_title_nn NOT NULL,
    genre         VARCHAR2(20)
        CONSTRAINT my_movies_genre_nn NOT NULL,
    rank          NUMBER
        CONSTRAINT my_movies_rank_uk UNIQUE
);

/* Creating sequences for primary keys */

CREATE SEQUENCE books_sequence;
CREATE SEQUENCE movies_sequence;

/* Creating procedures for inserting into tables */

CREATE OR REPLACE PROCEDURE insert_to_books_table
(
    book_title_to_insert    my_books.title%TYPE,
    book_genre_to_insert    my_books.genre%TYPE,
    book_rank_to_insert     my_books.rank%TYPE,
    book_id_to_insert       my_books.book_id%TYPE     DEFAULT   books_sequence.NEXTVAL
)
AS
BEGIN
    INSERT INTO my_books
    VALUES(book_id_to_insert, book_title_to_insert, book_genre_to_insert, book_rank_to_insert);

    COMMIT;
EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
END;

CREATE OR REPLACE PROCEDURE insert_to_movies_table
(
    movie_title_to_insert    my_movies.title%TYPE,
    movie_genre_to_insert    my_movies.genre%TYPE,
    movie_rank_to_insert     my_movies.rank%TYPE,
    movie_id_to_insert       my_movies.movie_id%TYPE  DEFAULT   movies_sequence.NEXTVAL
)
AS
BEGIN
    INSERT INTO my_movies
    VALUES(movie_id_to_insert, movie_title_to_insert, movie_genre_to_insert, movie_rank_to_insert);

    COMMIT;
EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
END;

/* Inserting into the tables */
CALL insert_to_books_table('Harry Potter', 'Fantasy Fiction', 1);
CALL insert_to_books_table('The Hunger Games', 'Fantasy Fiction', 3);
CALL insert_to_books_table('To Kill a Mockingbird', 'Coming-of-Age Fiction', 2);

CALL insert_to_movies_table('The Lion King', 'Family Film', 1);
CALL insert_to_movies_table('Beauty and the Beast', 'Family Film', 3);
CALL insert_to_movies_table('Aladdin', 'Family Film', 2);
