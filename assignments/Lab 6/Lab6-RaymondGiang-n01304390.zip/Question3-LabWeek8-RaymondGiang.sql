/* Lab Week 8 - Question 3
   Name: Raymond Giang
   Student Number: n01304390 */

/* 2. Create a stored function that can return the title based on your ranking. */

CREATE OR REPLACE FUNCTION get_book_title
(
    rank_param    my_books.rank%TYPE
)
RETURN VARCHAR2
AS
    book_title VARCHAR2(30);
BEGIN 
    SELECT title
    INTO book_title
    FROM my_books
    WHERE rank = rank_param;

    RETURN book_title;
END;

CREATE OR REPLACE FUNCTION get_movie_title
(
    rank_param    my_movies.rank%TYPE
)
RETURN VARCHAR2
AS
    movie_title VARCHAR2(20);
BEGIN 
    SELECT title
    INTO movie_title
    FROM my_movies
    WHERE rank = rank_param;

    RETURN movie_title;
END;