/* Lab Week 8 - Question 1
   Name: Raymond Giang
   Student Number: n01304390 */

/* 1. Create a stored procedure or function for anything from the previous weeks, the syntax of which 
you find difficult to remember. */

CREATE OR REPLACE FUNCTION get_balance_due
(
    invoice_id_param    invoices.invoice_id%TYPE
)
RETURN NUMBER
AS
    balance_due_var NUMBER;
BEGIN 
    SELECT invoice_total - payment_total - credit_total
    INTO balance_due_var
    FROM invoices
    WHERE invoice_id = invoice_id_param;

    RETURN balance_due_var;
END;