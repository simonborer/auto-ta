-- LAB 6 -Q1
-- Ekta Patel


SELECT * FROM order_details

CREATE OR REPLACE PROCEDURE update_order_quantity
(
    order_id_param NUMBER,
    order_qty_param NUMBER
)
AS
BEGIN
    UPDATE order_details
    SET order_qty = order_qty_param
    WHERE order_id = order_id_param;
    
    COMMIT;
EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
END;
/

CALL update_order_quantity(381,2);