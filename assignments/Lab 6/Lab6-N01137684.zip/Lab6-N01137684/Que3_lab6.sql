-- LAB 6 -Q1
-- Ekta Patel


CREATE OR REPLACE FUNCTION get_title
(
  rank_param NUMBER
)
RETURN VARCHAR
AS
  title_var VARCHAR(20);
BEGIN 
  SELECT title
  INTO title_var
  FROM my_books
  WHERE rank = rank_param;

  RETURN title_var;
END;
/

SELECT get_title(3)
FROM dual

-- For Movie table

CREATE OR REPLACE FUNCTION get_movie_title
(
  rank_param NUMBER
)
RETURN VARCHAR
AS
  title_var VARCHAR(20);
BEGIN 
  SELECT title
  INTO title_var
  FROM my_movies
  WHERE rank = rank_param;

  RETURN title_var;
END;
/

SELECT get_movie_title(3)
FROM dual