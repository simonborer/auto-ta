-- LAB 6 - Q2
-- Ekta Patel


CREATE TABLE my_books(
    book_id NUMBER(7) PRIMARY KEY,
    title VARCHAR(20),
    genre VARCHAR(15),
    rank NUMBER(5)
)

CREATE TABLE my_movies(
    movie_id NUMBER(7) PRIMARY KEY,
    title VARCHAR(20),
    genre VARCHAR(15),
    rank NUMBER(5)
)

CREATE OR REPLACE PROCEDURE insert_into_mybooks
(
    item_id_param NUMBER,
    title_param VARCHAR,
    genre_param VARCHAR,
    rank_param NUMBER
)
AS
BEGIN
    INSERT INTO my_books
    VALUES (item_id_param, title_param, genre_param,rank_param);
    
    COMMIT;
EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
END;
/

CALL insert_into_mybooks(1,'2 State','Lovestory',1);
CALL insert_into_mybooks(2,'Wings of fire','Novel',3);
CALL insert_into_mybooks(3,'Half girlfriend','Lovestory',2);

SELECT * FROM my_books;


CREATE OR REPLACE PROCEDURE insert_into_mymovies
(
    movie_id_param NUMBER,
    title_param VARCHAR,
    genre_param VARCHAR,
    rank_param NUMBER
)
AS
BEGIN
    INSERT INTO my_movies
    VALUES (movie_id_param, title_param, genre_param,rank_param);
    
    COMMIT;
EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
END;
/

CALL insert_into_mymovies(1,'Thugs of hindustan','Action',2);
CALL insert_into_mymovies(2,'3 idiot','Ispirational',1);
CALL insert_into_mymovies(3,'Raaz','Horror',3);

SELECT * FROM my_movies;

