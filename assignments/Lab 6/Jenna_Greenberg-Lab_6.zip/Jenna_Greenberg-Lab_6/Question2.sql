--Question 2 

CREATE TABLE new_fave_movies
(
  movie_id      NUMBER(3)   PRIMARY KEY,
  title         VARCHAR2(30) NOT NULL,
  genre         VARCHAR2(15),
  movie_rank          NUMBER(3)
  );
  
  CREATE TABLE new_fave_books
(
  book_id      NUMBER(3)   PRIMARY KEY,
  title         VARCHAR2(30) NOT NULL,
  genre         VARCHAR2(15),
  book_rank          NUMBER(3)
  );
  
  CREATE OR REPLACE PROCEDURE new_book_row (
  
    book_id_p       NUMBER,
    title_p         VARCHAR2,
    genre_p         VARCHAR2,
    book_rank_p       NUMBER
    
    )  
    AS
    BEGIN
    
    INSERT INTO new_fave_books (book_id, title, genre, book_rank)
    VALUES (book_id_p, title_p, genre_p, book_rank_p);
    
    END;
    /
    
  
     CALL new_book_row (001, "Oryx and Crake", "Sci-Fi", 1);
     CALL new_book_row (002, "Angels and Demons", "Sci-Fi", 2);
     CALL new_book_row (003, "A Little Life", "Fiction", 3);
     
 CREATE OR REPLACE PROCEDURE new_movie_row (
  
    movie_id_p       NUMBER,
    title_p         VARCHAR2,
    genre_p         VARCHAR2,
    movie_rank_p       NUMBER
    
    )  
    AS
    BEGIN
    
    INSERT INTO new_fave_movies (movie_id, title, genre, movie_rank)
    VALUES (movie_id_p, title_p, genre_p, movie_rank_p);
    
    END;
    /
    
    CALL new_movie_row(001, "The Dark Knight", "Action", 1);
    CALL new_movie_row(002, "A Star is Born", "Drama", 2);
    CALL new_movie_row(003, "Lord of the Rings", "Fantasy", 3);
    