--Question 1 Jenna Greenberg
CREATE OR REPLACE FUNCTION get_balance_due
(
    invoice_total_p invoices.invoice_total%TYPE,
    credit_total_p invoices.credit_total%TYPE,
    payment_total_p invoices.payment_total%TYPE
)
RETURN NUMBER
AS
balance_due_var NUMBER;

BEGIN 
SELECT invoice_total - credit_total - payment_total
INTO balance_due_var
FROM invoices;

RETURN balance_due_var;
END;
/