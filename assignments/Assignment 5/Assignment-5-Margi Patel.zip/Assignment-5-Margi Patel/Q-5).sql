--Margi Patel
--Assignment 5
--5)

SET SERVEROUTPUT ON;

VARIABLE bound_var VARCHAR(30);

DECLARE 
        sub_var1 VARCHAR(30);
        
BEGIN
        sub_var1 := '&sub_var1';
        
        :bound_var := sub_var1;
END;

DECLARE
        CURSOR invoice_cursor IS
        SELECT ( invoice_total - payment_total - credit_total ) AS "balance due", vendor_name, invoice_number
        FROM invoices i
        JOIN vendors v
        ON i.vendor_id = v.vendor_id
        
        WHERE ( invoice_total - payment_total - credit_total )  > :bound_var
        ORDER BY ( invoice_total - payment_total - credit_total ) DESC;
        
        sub_var1 VARCHAR(20);

BEGIN
        DBMS_OUTPUT.PUT_LINE(CHR(10) || 'New Section' || CHR(10) );
        DBMS_OUTPUT.PUT_LINE('Invoice amounts greater than or equal to $' || :bound_var);
        DBMS_OUTPUT.PUT_LINE('============================================================');
        FOR invoice_row IN invoice_cursor LOOP
        
        DBMS_OUTPUT.PUT_LINE(invoice_row."balance due" || ' ' || invoice_row.invoice_number || ' ' || invoice_row.vendor_name);
        
        END LOOP;
        
END;
