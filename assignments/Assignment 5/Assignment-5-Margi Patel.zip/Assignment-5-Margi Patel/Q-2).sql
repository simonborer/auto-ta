
--Margi Patel
--Assignment 5
--2)




SET SERVEROUTPUT ON;

DECLARE 
        no_of_invoice_balance NUMBER;
        total_balance_due NUMBER; 

BEGIN

 SELECT COUNT(invoice_id)
 INTO no_of_invoice_balance
 FROM invoices
 WHERE (invoice_total- payment_total- credit_total) > 0;
 
 DBMS_OUTPUT.PUT_LINE(no_of_invoice_balance || 'Number of unpaid invoices is 40' || CHR(10));


 SELECT SUM(invoice_total- payment_total- credit_total)
 INTO total_balance_due
 FROM invoices
 WHERE (invoice_total- payment_total- credit_total) > 0;


 IF(total_balance_due > 50000) THEN
 DBMS_OUTPUT.PUT_LINE('Total balance due is ' || total_balance_due || CHR(10));
 
 ELSE
 DBMS_OUTPUT.PUT_LINE('Total balance due is less than $50,000' || total_balance_due || CHR(10));

 END IF;

END;