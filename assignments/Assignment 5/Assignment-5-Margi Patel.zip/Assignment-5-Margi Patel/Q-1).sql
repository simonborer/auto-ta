--Margi Patel
--Assignment 5
--1)
SET SERVEROUTPUT ON;

-- Declaring variables 
DECLARE bound_var NUMBER;

BEGIN

 SELECT COUNT(invoice_id)
 INTO bound_var
 FROM invoices
 WHERE (invoice_total- payment_total- credit_total) >= 5000;
 
 DBMS_OUTPUT.PUT_LINE(bound_var || 'invoices exceed $5000' || CHR(10));

END;