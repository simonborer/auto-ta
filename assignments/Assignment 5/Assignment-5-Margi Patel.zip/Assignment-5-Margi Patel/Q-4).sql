--Margi Patel
--Assignment 5
--4)

SET SERVEROUTPUT ON;

DECLARE

    CURSOR invoice_cursor IS
    SELECT invoice_total - payment_total - credit_total AS "balance_due", invoice_number, vendor_name
    FROM invoices i
    JOIN vendors v
    ON i.vendor_id = v.vendor_id;
    
    
BEGIN 
        
    DBMS_OUTPUT.PUT_LINE('$20,000 or more');
    FOR invoice_row IN invoice_cursor LOOP
    IF ( invoice_row."balance_due" >= 20000 ) THEN
        DBMS_OUTPUT.PUT_LINE(invoice_row."balance_due" || ' ' || invoice_row.invoice_number || ' ' || invoice_row.vendor_name);
    END IF;
    END LOOP;
    
    DBMS_OUTPUT.PUT_LINE('$10,000 to $20,000');
    FOR invoice_row IN invoice_cursor LOOP
    IF( invoice_row."balance_due" >=10000 and invoice_row."balance_due" <= 20000 ) THEN
        DBMS_OUTPUT.PUT_LINE(invoice_row."balance_due" || ' ' || invoice_row.invoice_number || ' ' || invoice_row.vendor_name);
    END IF;
    END LOOP;
    
    DBMS_OUTPUT.PUT_LINE('$5,000 to $10,000');
    FOR invoice_row IN invoice_cursor LOOP
    IF( invoice_row."balance_due" >= 5000 and invoice_row."balance_due" <= 10000 ) THEN
        DBMS_OUTPUT.PUT_LINE(invoice_row."balance_due" || ' ' || invoice_row.invoice_number || ' ' || invoice_row.vendor_name);
    END IF;
    END LOOP;
    
END;