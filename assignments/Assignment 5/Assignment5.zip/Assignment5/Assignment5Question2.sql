SET SERVEROUTPUT ON;
DECLARE 
    balance_due_counter NUMBER;
    balance_sum NUMBER;
BEGIN
    balance_sum:=0;
    balance_due_counter:=0;
    FOR i IN (SELECT invoice_total, payment_total, credit_total FROM invoices) LOOP
        IF(i.invoice_total - i.payment_total - i.credit_total>0) THEN
            balance_due_counter:= balance_due_counter+1;
        END IF;
        balance_sum := balance_sum + (i.invoice_total - i.payment_total - i.credit_total);
    END LOOP;
    IF balance_sum<50000 THEN
        DBMS_OUTPUT.PUT_LINE('Total balanace due is less than $50,000');
    ELSE
        DBMS_OUTPUT.PUT_LINE('Number of unpaid invoices is ' || balance_due_counter || '.');
        DBMS_OUTPUT.PUT_LINE('Total balance due is $' || balance_sum);
    END IF;
END;

    