SET SERVEROUTPUT ON;
DECLARE
CURSOR char_cursor IS 
    SELECT vendor_name, invoice_number, invoice_total-payment_total-credit_total AS balance_due
    FROM invoices i
    JOIN vendors v
    ON i.vendor_id = v.vendor_id
    WHERE invoice_total-payment_total-credit_total >=5000
    ORDER BY balance_due DESC;

BEGIN
FOR char_row IN char_cursor LOOP
    DBMS_OUTPUT.PUT_LINE(char_row.balance_due || ' ' || char_row.invoice_number || ' ' || char_row.vendor_name);
END LOOP;
END;

