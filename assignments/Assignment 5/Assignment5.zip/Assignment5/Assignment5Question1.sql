SET SERVEROUTPUT ON;
DECLARE
    counter NUMBER;
BEGIN
    SELECT COUNT(*)
    INTO counter
    FROM invoices
    WHERE (invoice_total-payment_total-credit_total)>=5000;
    DBMS_OUTPUT.PUT_LINE(counter || ' invoices exceed $5000.');
END;
