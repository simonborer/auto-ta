-- Question 5
SET SERVEROUTPUT ON;
VARIABLE bound_balance_min NUMBER;

DECLARE 

min_balance NUMBER;
CURSOR char_vendors IS
  SELECT vendor_name, i.invoice_id, (invoice_total - payment_total - credit_total)AS balance_due
    FROM invoices i JOIN vendors v ON i.vendor_id = v.vendor_id 

    ORDER BY (invoice_total - payment_total - credit_total) DESC;
    
BEGIN  
min_balance := '&min_balance'; 
:bound_balance_min := min_balance;
DBMS_OUTPUT.PUT_LINE('Invoice amounts are greater than '|| :bound_balance_min);
FOR char_row IN char_vendors LOOP
IF (char_row.balance_due > :bound_balance_min) THEN
DBMS_OUTPUT.PUT_LINE( char_row.balance_due || ' ' || char_row.vendor_name ||' ' || char_row.invoice_id);
END IF;
END LOOP;
END;