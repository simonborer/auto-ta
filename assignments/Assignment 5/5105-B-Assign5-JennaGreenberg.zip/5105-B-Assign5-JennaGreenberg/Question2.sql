-- Question 2

SET SERVEROUTPUT ON;
DECLARE
    number_of_invoices NUMBER;
    sum_of_invoices NUMBER;

BEGIN
    SELECT COUNT(invoice_id), SUM(invoice_id)
    INTO number_of_invoices, sum_of_invoices
    FROM invoices
    WHERE (invoice_total - payment_total - credit_total) > 0;
    
    IF sum_of_invoices > 50000 THEN
    DBMS_OUTPUT.PUT_LINE('number of unpaid invoices is ' || number_of_invoices ||
    'Total balance due is ' || sum_of_invoices);
    
    ELSIF sum_of_invoices < 50000 THEN
    DBMS_OUTPUT.PUT_LINE('Total balance due is less than $50,000');
    
    END IF;
END;
    