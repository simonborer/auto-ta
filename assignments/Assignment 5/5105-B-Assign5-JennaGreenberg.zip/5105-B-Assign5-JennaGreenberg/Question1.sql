--Question 1

SET SERVEROUTPUT ON;
DECLARE
    number_of_invoices  NUMBER;
    
BEGIN
    SELECT COUNT(invoice_id)
    INTO number_of_invoices
    FROM invoices
    WHERE (invoice_total - payment_total - credit_total) >= 5000;

    DBMS_OUTPUT.PUT_LINE(number_of_invoices || ' invoices exceed 5000');
END;