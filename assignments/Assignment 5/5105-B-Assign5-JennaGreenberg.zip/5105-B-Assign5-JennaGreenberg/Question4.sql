--Question 4
SET SERVEROUTPUT ON;
DECLARE

CURSOR char_vendors IS
  SELECT vendor_name, i.invoice_id, (invoice_total - payment_total - credit_total)AS balance_due
    FROM invoices i JOIN vendors v ON i.vendor_id = v.vendor_id 
    WHERE (invoice_total - payment_total - credit_total) > 5000
    ORDER BY (invoice_total - payment_total - credit_total) DESC;
    
BEGIN    
FOR char_row IN char_vendors LOOP
IF (char_row.balance_due > 20000) THEN
DBMS_OUTPUT.PUT_LINE('Over 20,000');
DBMS_OUTPUT.PUT_LINE(char_row.balance_due|| CHR(10));
ELSIF (char_row.balance_due BETWEEN 10000 AND 20000) THEN
DBMS_OUTPUT.PUT_LINE('Between 10,000 and 20,000');
DBMS_OUTPUT.PUT_LINE(char_row.balance_due || CHR(10));
ELSIF (char_row.balance_due BETWEEN 5000 AND 10000) THEN
DBMS_OUTPUT.PUT_LINE('Between 5,000 and 10,000');
DBMS_OUTPUT.PUT_LINE(char_row.balance_due || CHR(10));
END IF;
END LOOP;
END;