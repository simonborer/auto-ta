-- Assignment 5 Ekta Patel
-- Que 3
SET SERVEROUTPUT ON;

DECLARE
    CURSOR invoice_cursor IS 
    SELECT invoice_total-payment_total-credit_total AS "Balance Due", invoice_number, vendor_name 
    FROM invoices i
    JOIN vendors v
    ON i.vendor_id = v.vendor_id
    WHERE (invoice_total-payment_total-credit_total)> 5000
    ORDER BY invoice_total-payment_total-credit_total DESC;

BEGIN
    FOR invoice_row IN invoice_cursor LOOP
        DBMS_OUTPUT.PUT_LINE(invoice_row."Balance Due"||'   '||invoice_row.invoice_number || '    ' ||invoice_row.vendor_name);
    END LOOP;
END;