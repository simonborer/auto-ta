-- Assignment 5 Ekta Patel
-- Que 1
SET SERVEROUTPUT ON;

DECLARE
    no_of_invoices NUMBER;

BEGIN
    SELECT COUNT(invoice_id) 
    INTO no_of_invoices
    FROM invoices 
    WHERE (invoice_total-payment_total-credit_total)>5000;
    DBMS_OUTPUT.PUT_LINE(no_of_invoices || ' invoices exceed $5,000.' || CHR(10));
END;
