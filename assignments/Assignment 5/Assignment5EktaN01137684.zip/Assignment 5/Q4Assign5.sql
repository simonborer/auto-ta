-- Assignment 5 Ekta Patel
-- Que 4

SET SERVEROUTPUT ON;

DECLARE
    CURSOR invoice_cursor IS 
    SELECT invoice_total-payment_total-credit_total AS "Balance Due", invoice_number, vendor_name 
    FROM invoices i
    JOIN vendors v
    ON i.vendor_id = v.vendor_id;

BEGIN
    DBMS_OUTPUT.PUT_LINE('$20,000 or more');
    FOR invoice_row IN invoice_cursor LOOP
    IF (invoice_row."Balance Due" >= 20000) THEN
        DBMS_OUTPUT.PUT_LINE(invoice_row."Balance Due"||'   '||invoice_row.invoice_number || '    ' ||invoice_row.vendor_name);
    END IF;
    END LOOP;
    DBMS_OUTPUT.PUT_LINE('$10,000 to $20,000');
    FOR invoice_row IN invoice_cursor LOOP
    IF (invoice_row."Balance Due" >= 10000 and invoice_row."Balance Due" < 20000) THEN
        DBMS_OUTPUT.PUT_LINE(invoice_row."Balance Due"||'   '||invoice_row.invoice_number || '    ' ||invoice_row.vendor_name);
    END IF;
    END LOOP;
    DBMS_OUTPUT.PUT_LINE('$5,000 to $10,000');
    FOR invoice_row IN invoice_cursor LOOP
    IF (invoice_row."Balance Due" > 5000 and invoice_row."Balance Due" < 10000) THEN
        DBMS_OUTPUT.PUT_LINE(invoice_row."Balance Due"||'   '||invoice_row.invoice_number || '    ' ||invoice_row.vendor_name);
    END IF;
    END LOOP;
END;