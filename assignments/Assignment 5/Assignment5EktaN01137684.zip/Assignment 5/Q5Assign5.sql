-- Assignment 5 Ekta Patel
-- Que 4

SET SERVEROUTPUT ON;

VARIABLE bound_var  VARCHAR2(20);

DECLARE
    sub_var    VARCHAR2(20);

BEGIN
    sub_var := '&sub_var';
        
    :bound_var := sub_var;
END;
/
DECLARE
    CURSOR invoice_cursor IS 
    SELECT invoice_total-payment_total-credit_total AS "Balance Due", invoice_number, vendor_name 
    FROM invoices i
    JOIN vendors v
    ON i.vendor_id = v.vendor_id
    WHERE (invoice_total-payment_total-credit_total)> :bound_var
    ORDER BY invoice_total-payment_total-credit_total DESC;
    
    sub_var    VARCHAR2(20);
BEGIN
	DBMS_OUTPUT.PUT_LINE(CHR(10) || 'New block!' || CHR(10));
    DBMS_OUTPUT.PUT_LINE('Invoices amount greater than or equal to $' || :bound_var);
    DBMS_OUTPUT.PUT_LINE('=====================================================');
    FOR invoice_row IN invoice_cursor LOOP
        DBMS_OUTPUT.PUT_LINE(invoice_row."Balance Due"||'   '||invoice_row.invoice_number || '    ' ||invoice_row.vendor_name);
    END LOOP;
END;
/

