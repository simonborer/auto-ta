/* Mariya An, Assignment 5*/

--Question1

SET SERVEROUTPUT ON;
DECLARE 
    balance_due NUMBER;
BEGIN
 SELECT COUNT(*) 
 INTO balance_due
 FROM invoices
 WHERE (invoice_total-payment_total-credit_total)>=5000;

DBMS_OUTPUT.PUT_LINE(balance_due ||' ' || 'invoices exceed $5000');
END;


 
 


