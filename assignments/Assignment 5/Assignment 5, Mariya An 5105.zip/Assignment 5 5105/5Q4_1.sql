--Mariya An, Assignment 5, Question 4
SET SERVEROUTPUT ON;
DECLARE 
    CURSOR vendor_cursor IS
    SELECT vendor_name, invoice_number, (invoice_total-payment_total-credit_total) AS balance_due
    FROM invoices i
    JOIN vendors v
    ON i.vendor_id=v.vendor_id
    WHERE (invoice_total-payment_total-credit_total)>=5000
    ORDER BY balance_due DESC;
    
    vendor_row NUMBER;
BEGIN
    FOR vendor_row IN vendor_cursor LOOP 
    IF (vendor_row.balance_due>=20000)
    THEN DBMS_OUTPUT.PUT_LINE('Total balance due is '||' $'||vendor_row.balance_due|| ', result falls into group $20000 or more'|| CHR(10));
    ELSIF(vendor_row.balance_due BETWEEN 10000 AND 20000)
    THEN DBMS_OUTPUT.PUT_LINE('Total balance due is ' ||' $'||vendor_row.balance_due|| ', result falls into group $10000 to $20000'|| CHR(10));
    ELSE DBMS_OUTPUT.PUT_LINE('Total balance due is '||' $'||vendor_row.balance_due|| ', result falls into group between $5000 to $10000'|| CHR(10));
END IF;   
END LOOP;
END;
 
/