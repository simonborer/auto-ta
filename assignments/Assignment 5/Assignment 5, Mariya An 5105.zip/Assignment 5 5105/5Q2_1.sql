--Mariya An, Assignment 5, Question 2
SET SERVEROUTPUT ON;
DECLARE
 count_balance_due NUMBER;
 total_balance_due NUMBER;
BEGIN
    SELECT COUNT(*)
    INTO count_balance_due
    FROM invoices 
    WHERE (invoice_total-payment_total-credit_total)>0;
  DBMS_OUTPUT.PUT_LINE('Number of unpaid invoices is ' || count_balance_due) ;

   SELECT SUM(invoice_total-payment_total-credit_total)
   INTO total_balance_due
   FROM invoices
   HAVING SUM(invoice_total-payment_total-credit_total)>0;
 
  IF
  total_balance_due >5000
  THEN DBMS_OUTPUT.PUT_LINE('Total balance due is ' || total_balance_due);
  ELSE
  DBMS_OUTPUT.PUT_LINE('Total balance due is less than $50000 ');
 
END IF; 
END;
 